//
//  FrameworkGridViewModel.swift
//  appleFrameWork-iOS
//
//  Created by Esakki-IOS on 12/07/24.
//

import SwiftUI

final class FrameworkGridViewModel: ObservableObject {
    
    let columns: [GridItem] = [GridItem(.flexible()),
                               GridItem(.flexible()),
                               GridItem(.flexible())]
}
