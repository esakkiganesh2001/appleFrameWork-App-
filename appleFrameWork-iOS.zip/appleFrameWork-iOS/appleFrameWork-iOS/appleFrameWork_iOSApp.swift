//
//  appleFrameWork_iOSApp.swift
//  appleFrameWork-iOS
//
// Created by Esakki-IOS on 12/07/24.
//

import SwiftUI

@main
struct appleFrameWork_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            FrameworkGridView()
        }
    }
}
